﻿public class ShippingService
{
    private const double FreeShippingThreshold = 3000; // порог для бесплатной доставки
    private const double FixedShippingThreshold = 1000; // порог для фиксированной доставки
    private const double FixedOrderShippingCost = 230; // стоимость доставки
    private const double ExpressShippingCostCoefficient = 2; // коэффициент для экспресс-доставки

    public double CalculateDeliveryCost(double total, bool isExpress)
    {
        double deliveryCost = CalculateBaseDeliveryCost(total);
        return CalculateExpressDelivery(isExpress, deliveryCost);
    }

    private double CalculateBaseDeliveryCost(double total)
    {
        if (total < FixedShippingThreshold)
            return total; // Стоимость доставки равна стоимости заказа
        if (total < FreeShippingThreshold)
            return FixedOrderShippingCost; // Фиксированная стоимость доставки
        return 0; // Бесплатная доставка
    }

    private static double CalculateExpressDelivery(bool isExpress, double deliveryCost)
    {
        if (isExpress)
            deliveryCost *= ExpressShippingCostCoefficient;
        return deliveryCost;
    }
}
