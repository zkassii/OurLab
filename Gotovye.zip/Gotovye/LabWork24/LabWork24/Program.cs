﻿Order orderService = new();

var order = new Order {Id = 2228, Total = 2700, IsExpress = false, Address = "Папанина, 24" };
orderService.AddOrder(order);

orderService.PrintOrderDetails(order.Id);

Console.WriteLine("Полная стоимость: " + orderService.CalculateTotalPrice(order));
