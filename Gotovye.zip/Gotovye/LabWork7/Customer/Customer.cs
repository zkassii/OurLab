﻿public class Customer
{
    public string FullName { get; set; }
    public string Address { get; set; }
    public decimal AmountSpent { get; set; }

    public Customer(string fullName, string address, decimal amountSpent)
    {
        FullName = fullName;
        Address = address;
        AmountSpent = amountSpent;
    }

    public void Display()
    {
        Console.WriteLine($"ФИО: {FullName}, Адрес: {Address}, Потраченная сумма: {AmountSpent}");
    }
    //1
    public static Customer operator ++(Customer customer)
    {
        return new(customer.FullName, customer.Address, customer.AmountSpent + 1);
    }
    //2
    public static Customer operator +(Customer c1, Customer c2)
    {
        return new(c1.FullName, c1.Address, c1.AmountSpent + c2.AmountSpent);
    }
    //3
    public static bool operator ==(Customer c1, Customer c2)
    {
        return c1.FullName == c2.FullName && c1.Address == c2.Address && c1.AmountSpent == c2.AmountSpent;
    }

    public static bool operator !=(Customer c1, Customer c2)
    {
        return !(c1 == c2);
    }
    //4
    public static bool operator true(Customer c1)
    {
        return c1.AmountSpent >= 0;
    }

    public static bool operator false(Customer c1)
    {
        return c1.AmountSpent < 0;
    }
}

