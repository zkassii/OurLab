﻿Customer customer1 = new("Пирожков Андрей Владимирович", "г. Архангельск, ул. Воскресенская, д. 19", 150);
customer1.Display();

Customer customerAfterIncrement = ++customer1;
customerAfterIncrement.Display();

Customer customer2 = new("Рыбков Алексей Александрович", "г. Пенза, ул. Мира, д. 12", 450);
customer2.Display();

Customer customer3 = new("Рыбков Алексей Александрович", "г. Пенза, ул. Мира, д. 12", 450);

Customer customerSum = customer1 + customer2;
customerSum.Display();

Console.WriteLine();
Console.WriteLine($"Сравнение customer1 и customer2: {customer1 != customer2}");
Console.WriteLine($"Сравнение customer2 и customer3: {customer2 == customer3}");
Console.WriteLine($"Сравнение customer2 и customer3: {customer2 != customer3}");

Console.WriteLine();
if (customerSum)
{
    Console.WriteLine("true");
}
else
{
    Console.WriteLine("false");
}
