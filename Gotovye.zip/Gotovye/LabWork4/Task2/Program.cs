﻿int[] array = { 1, 3, 7, 5, 8 };
int localMaximum = FindLocalMaximum(array);
Console.WriteLine("Первый локальный максимум: " + localMaximum);

static int FindLocalMaximum(int[] array)
{
    if (array.Length > 1 && array[0] > array[1])
        return array[0];

    for (int i = 1; i < array.Length - 1; i++)
    {
        if (array[i] > array[i - 1] && array[i] > array[i + 1])
            return array[i];
    }

    if (array.Length > 1 && array[array.Length - 1] > array[array.Length - 2])
        return array[array.Length - 1];

    return -1;
}