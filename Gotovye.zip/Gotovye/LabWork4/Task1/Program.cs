﻿List<int> coins = new List<int> { 1, 3, 4 };
int amount = 6;

List<int> change = GetChange(amount, coins);

Console.WriteLine("Ваша сдача: " + string.Join(", ", change));

static List<int> GetChange(int amount, List<int> coins)
{
    List<int> result = new List<int>();

    coins.Sort();
    coins.Reverse();

    foreach (int coin in coins)
    {
        while (amount >= coin)
        {
            amount -= coin;
            result.Add(coin);
        }

        if (amount == 0)
            break;
    }
    return result;
}