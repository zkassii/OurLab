﻿using System.Text.RegularExpressions;

string phonePattern = @"^(\+7\(9\d{2}\)\d{3}-\d{2}-\d{2}|8\(9\d{2}\)\d{3}-\d{2}-\d{2})$";
string numberPhone = "+7(921)283-83-81";
string numberPhone2 = "8(921)283-83-81";

bool isPhoneValid = Regex.IsMatch(numberPhone, phonePattern);
Console.WriteLine($"Номер телефона {numberPhone} корректен: {isPhoneValid}");

bool isPhoneValid2 = Regex.IsMatch(numberPhone2, phonePattern);
Console.WriteLine($"Номер телефона {numberPhone2} корректен: {isPhoneValid2}");