﻿using System.Text.RegularExpressions;
string passwordPattern = @"^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[?!.])[A-Za-z0-9.?!]{6,}$";
string password;

do
{
    Console.WriteLine("Введите пароль: ");
    password = Console.ReadLine();
    if (Regex.IsMatch(password, passwordPattern))
        Console.WriteLine("Пароль надежен");
    else
        Console.WriteLine("Пароль не соответствует требованиям");
}
while (!Regex.IsMatch(password, passwordPattern));