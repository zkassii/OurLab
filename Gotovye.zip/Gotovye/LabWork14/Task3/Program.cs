﻿using System.Text.RegularExpressions;

string emailPattern = @"^[a-zA-Z0-9_-]+@[a-zA-Z0-9]+(\.[a-zA-Z]{2,})$";
string email = "loloshka@gmail.com";

bool isEmailValid = Regex.IsMatch(email, emailPattern, RegexOptions.IgnoreCase);
Console.WriteLine($"E-mail {email} корректен: {isEmailValid}");