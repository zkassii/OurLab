﻿// Тестирование класса Customer
using LabWork8;

Customer customer1 = new Customer("Иванов Алексей", "ул. Мира, 1", 5600);
Customer customer2 = new Customer("Окунь Александр", "ул. Папанина, 18", 1000);
Customer customer3 = new Customer("Щукин Петр", "ул. Ленина, 278", 2400);

Console.WriteLine("Тестирование ToString():");
Console.WriteLine(customer1.ToString());
Console.WriteLine(customer1); // неявный вызов ToString()

Console.WriteLine("\nТестирование Equals():");
Console.WriteLine($"customer1 и customer2: {customer1.Equals(customer2)}");
Console.WriteLine($"customer1 и customer3: {customer1.Equals(customer3)}");

// Тестирование класса Square
Square square = new Square(5);
Console.WriteLine("\nТестирование класса Square:");
square.PrintInfo();

// Тестирование CustomRandom
CustomRandom customRandom = new CustomRandom();
Console.WriteLine("\nТестирование CustomRandom:");
Console.WriteLine($"Случайная строка: {customRandom.GetRandomUpperCaseString(10)}");