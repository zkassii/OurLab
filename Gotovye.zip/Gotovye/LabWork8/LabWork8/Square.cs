﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabWork8
{
    public class Square : Shape
    {
        public double Side { get; set; }

        public Square(double side)
        {
            Side = side;
        }

        public override string Name => "Квадрат";

        public override double GetArea()
        {
            return Side * Side;
        }

        public override double GetPerimeter()
        {
            return 4 * Side;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"Фигура: {Name}, Сторона: {Side}, Площадь: {GetArea()}, Периметр: {GetPerimeter()}");
        }
    }
}
