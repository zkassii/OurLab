﻿
Customer customer1 = new();
customer1.DisplayInformation();

Console.WriteLine();

Customer customer2 = new("Пукшина Анастасия Андреевна", "Архангельск, ул. Урицкого, 11", 3000);
customer2.DisplayInformation();

Console.WriteLine();

Test(customer2, "Имя", "");
Test(customer2, "Адрес", "");
Test(customer2, "Потраченная сумма", 1500m);

customer2.Name = "Пукшина Анастасия Андреевна";
customer2.Address = "Архангельск, ул. Урицкого, 11";
customer2.SpentAmount = 3000;

customer2.DisplayInformation();


static void Test(Customer customer, string propertyName, object value)
{
    try
    {
        switch (propertyName)
        {
            case "Имя":
                customer.Name = value.ToString();
                break;
            case "Адрес":
                customer.Address = value.ToString();
                break;
            case "Потраченная сумма":
                customer.SpentAmount = (decimal)value;
                break;
        }
    }
    catch (ArgumentException ex)
    {
        Console.WriteLine(ex.Message);
    }
}


