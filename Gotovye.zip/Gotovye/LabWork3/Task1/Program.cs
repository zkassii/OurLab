﻿using System.Diagnostics;

int factorialResult = Factorial(5);
Console.WriteLine($"Факториал 5 = {factorialResult}");
static int Factorial(int n)
{
    Debug.WriteLine($"Вызов n = {n}");
    return n < 0 ? 0 : n == 0 ? 1 : n * Factorial(n - 1);
}
Debug.Assert(Factorial(0) == 1);
Debug.Assert(Factorial(-4) == 0);
Debug.Assert(Factorial(5) == 120);