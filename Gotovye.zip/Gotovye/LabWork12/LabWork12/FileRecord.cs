﻿record FileRecord
{
    public string FileName { get; set; }
    public string FullPath { get; set; }
    public int FileSize { get; set; }

    public override string ToString()
        => $"Имя файла: {FileName}, Путь: {FullPath}, Размер: {FileSize}";
}