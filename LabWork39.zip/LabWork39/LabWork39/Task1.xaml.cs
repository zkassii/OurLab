﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace LabWork39
{
    /// <summary>
    /// Логика взаимодействия для Task1.xaml
    /// </summary>
    public partial class Task1 : Page
    {
        public Task1()
        {
            InitializeComponent();
            LoadFileData();
        }
        private void LoadFileData()
        {
            string path = "C:\\LabProgram"; // Укажите путь к вашей папке
            DirectoryInfo directory = new DirectoryInfo(path);
            IEnumerable<FileInfo> files = directory.GetFiles("*", SearchOption.AllDirectories);

            var fileGroups = files
                .GroupBy(f => f.Extension)
                .Select(g => new
                {
                    Extension = g.Key,
                    TotalSize = g.Sum(f => f.Length),
                    MinSize = g.Min(f => f.Length),
                    MaxSize = g.Max(f => f.Length),
                    Count = g.Count()
                }).ToList();

            fileListView.ItemsSource = fileGroups; // Привязываем данные
        }
    }
}
