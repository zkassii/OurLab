﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Circles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly Random random = new();
        private readonly string[] tags = { "enemy", "hero", "treasure" };
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Canvas_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Console.WriteLine("MouseDown event fired!");
            Point position = e.GetPosition(canvas);

            var circle = new Ellipse
            {
                Width = random.Next(20, 100),
                Height = random.Next(20, 100),
                Fill = new SolidColorBrush(Color.FromRgb(
                     (byte)random.Next(256),
                     (byte)random.Next(256),
                     (byte)random.Next(256))),
                Stroke = Brushes.Black,
                StrokeThickness = 2,
                Tag = tags[random.Next(tags.Length)]
            };

            // Позиционируем (центрируем вокруг точки клика)
            Canvas.SetLeft(circle, position.X - circle.Width / 2);
            Canvas.SetTop(circle, position.Y - circle.Height / 2);

            // Обработчик клика по кругу
            circle.MouseDown += (s, args) =>
            {
                args.Handled = true;
                MessageBox.Show($"Вы кликнули на: {((Ellipse)s).Tag}");
            };

            canvas.Children.Add(circle);

            // Отладочное сообщение
            Console.WriteLine($"Circle added at {position}, tag: {circle.Tag}"); 
        }
    }
}