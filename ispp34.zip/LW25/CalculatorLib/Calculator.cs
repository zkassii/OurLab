﻿namespace CalculatorLib;

public class Calculator
{
    /// <summary>
    /// выполняет сложение чисел
    /// </summary>
    public int Add(int a, int b)
    {
        return a + b;
    }
    /// <summary>
    /// выполняет умножение чисел
    /// </summary>
    public int Mul (int a, int b)
    {
        return a * b;
    }
    /// <summary>
    /// выполняет деление чисел
    /// </summary>
    public int Div(int a, int b)
    {
        if (b == 0)
            throw new InvalidOperationException("НЕЛЬЗЯ ДЕЛИТЬ НА НОЛЬ");
        return a / b;
    }
}
