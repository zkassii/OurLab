using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;

namespace PractWork3
{
    public partial class WordDocumentCreator : Form
    {
        public WordDocumentCreator()
        {
            InitializeComponent();
        }

        private void CreatingButton_Click(object sender, EventArgs e)
        {
            string inputText = InputTextBox.Text;
            int taskCount = (int)TasksCountNumericUpDown.Value;

            Word.Application _wordApp = new();
            Word.Document _wordDoc = _wordApp.Documents.Open(@"C:\Temp\ispp34\PractWork3\PractWork3\bin\Debug\net8.0-windows\������.docx");
            _wordApp.Visible = true;

            _wordDoc.Content.Font.Name = "Times New Roman";
            _wordDoc.Content.Font.Size = 14;
            _wordDoc.Content.ParagraphFormat.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            FindAndReplace(_wordDoc, "{����������������}", inputText);
            FindAndReplace(_wordDoc, "{��.��.���� ��:��}", DateTime.Now.ToString());

            Word.Range range = _wordDoc.Range();
            Table table = _wordDoc.Tables.Add(range, taskCount + 1, 2);
            table.Borders.Enable = 1;
            table.Cell(1, 1).Range.Text = "�";
            table.Cell(1, 2).Range.Text = "�����";

            for (int i = 1; i <= taskCount; i++)
            {
                table.Cell(i + 1, 1).Range.Text = i.ToString();
                table.Cell(i + 1, 2).Range.Text = "";
            }

            Word.InlineShape shape = _wordDoc.InlineShapes.AddPicture(@"C:\Temp\ispp34\PractWork3\PractWork3\bin\Debug\net8.0-windows\1500452276_preview_banana.jpg", LinkToFile: false, SaveWithDocument: true);
            shape.Width = 100;
            shape.Height = 50;
            shape.ConvertToShape();

            _wordDoc.Close();
            _wordApp.Quit();

        }

        private void FindAndReplace(Word.Document doc, object findText, object replaceWithText)
        {
            Word.Find findObject = doc.Content.Find;
            findObject.Text = (string)findText; 
            findObject.Replacement.Text = (string)replaceWithText;
            object wrap = Word.WdFindWrap.wdFindContinue; 
            findObject.Execute(FindText: ref findText, Replace: Word.WdReplace.wdReplaceAll, Wrap: ref wrap);
        }

        private void NewDocumentButton_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new())
            {
                saveFileDialog.Filter = "Word documents (*.docx)|*.docx|PDF files (*.pdf)|*.pdf";
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string format = saveFileDialog.FilterIndex == 1 ? "docx" : "pdf";
                }
            }
        }
    }
}

