﻿namespace PractWork3
{
    partial class WordDocumentCreator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            InputTextBox = new TextBox();
            CreatingButton = new Button();
            saveFileDialog1 = new SaveFileDialog();
            NewDocumentButton = new Button();
            TasksCountNumericUpDown = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)TasksCountNumericUpDown).BeginInit();
            SuspendLayout();
            // 
            // InputTextBox
            // 
            InputTextBox.Location = new Point(12, 46);
            InputTextBox.Multiline = true;
            InputTextBox.Name = "InputTextBox";
            InputTextBox.Size = new Size(380, 258);
            InputTextBox.TabIndex = 0;
            // 
            // CreatingButton
            // 
            CreatingButton.Location = new Point(95, 310);
            CreatingButton.Name = "CreatingButton";
            CreatingButton.Size = new Size(208, 42);
            CreatingButton.TabIndex = 2;
            CreatingButton.Text = "Создать документ по шаблону";
            CreatingButton.UseVisualStyleBackColor = true;
            CreatingButton.Click += CreatingButton_Click;
            // 
            // NewDocumentButton
            // 
            NewDocumentButton.Location = new Point(129, 393);
            NewDocumentButton.Name = "NewDocumentButton";
            NewDocumentButton.Size = new Size(75, 23);
            NewDocumentButton.TabIndex = 3;
            NewDocumentButton.Text = "button1";
            NewDocumentButton.UseVisualStyleBackColor = true;
            NewDocumentButton.Click += NewDocumentButton_Click;
            // 
            // TasksCountNumericUpDown
            // 
            TasksCountNumericUpDown.Location = new Point(12, 12);
            TasksCountNumericUpDown.Name = "TasksCountNumericUpDown";
            TasksCountNumericUpDown.Size = new Size(120, 23);
            TasksCountNumericUpDown.TabIndex = 4;
            // 
            // WordDocumentCreator
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(404, 485);
            Controls.Add(TasksCountNumericUpDown);
            Controls.Add(NewDocumentButton);
            Controls.Add(CreatingButton);
            Controls.Add(InputTextBox);
            Name = "WordDocumentCreator";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)TasksCountNumericUpDown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox InputTextBox;
        private Button CreatingButton;
        private SaveFileDialog saveFileDialog1;
        private Button NewDocumentButton;
        private NumericUpDown TasksCountNumericUpDown;
    }
}
