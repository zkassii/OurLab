﻿namespace Task2Lib
{  
    Install-Package EPPlus
    public class Class1
    {

    }
}
