﻿using ClosedXML.Excel;

class Program
{
    static void Main(string[] args)
    {
        string templateBook = "excelbook.xlsx";
        string outputBook = "newexcelbook.xlsx";

        using (var workbook = new XLWorkbook(templateBook))
        {
            var filesSheet = workbook.Worksheet("Файлы");
            var subfoldersSheet = workbook.Worksheet("Подпапки");

            var directoryPath = @"C:\Temp\ispp34\PractWork2";

            var files = Directory.GetFiles(directoryPath);
            int row = 2;

            foreach (var file in files)
            {
                var fileInfo = new FileInfo(file);
                filesSheet.Cell(row, 1).Value = row - 1;
                filesSheet.Cell(row, 2).Value = fileInfo.Name;
                filesSheet.Cell(row, 3).Value = fileInfo.Length;
                row++;
            }

            var directories = Directory.GetDirectories(directoryPath);
            row = 2;

            foreach (var directory in directories)
            {
                var directoryInfo = new DirectoryInfo(directory);
                subfoldersSheet.Cell(row, 1).Value = row - 1;
                subfoldersSheet.Cell(row, 2).Value = directoryInfo.Name;
                row++;
            }

            workbook.SaveAs(outputBook);
            Console.WriteLine("Создана новая книга: " + outputBook);
        }
    }
}
