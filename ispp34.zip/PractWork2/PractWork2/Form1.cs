namespace PractWork2
{
    public partial class Form1 : Form
    {
        private const string FilePath = "logins.csv";

        public Form1()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Text;

            if (IsUsernameExists(username))
            {
                MessageBox.Show("����� ��� ����������. ����������, ������� ������ �����.");
                return;
            }

            RegisterUser(username, password);
            MessageBox.Show("�� ����������������!");
        }

        private bool IsUsernameExists(string username)
        {
            if (!File.Exists(FilePath))
                return false;

            var lines = File.ReadAllLines(FilePath);
            return lines.Any(line => line.Split(';')[0].Equals(username, StringComparison.OrdinalIgnoreCase));
        }

        private void RegisterUser(string username, string password)
        {
            string registrationDate = DateTime.Now.ToString("yyyy-MM-dd");
            string newUser = $"{username};{password};{registrationDate}";
            File.AppendAllText(FilePath, newUser + Environment.NewLine);
        }
    }
}
