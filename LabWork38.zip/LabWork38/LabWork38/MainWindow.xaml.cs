﻿using System.Data;
using System.IO;
using System.Windows;

namespace LabWork38
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int PageSize { get; set; } = 5;
        public int CurrentPage { get; set; } = 1;
        private FileInfo[] allFiles;
        public MainWindow()
        {
            InitializeComponent();
            LoadFiles();
            ShowFiles();
        }

        private void LoadFiles()
        {
            var path = "C:\\Temp\\ispp31";
            var directory = new DirectoryInfo(path);
            allFiles = directory.GetFiles().OrderBy(f => f.Name).ToArray();
        }

        private void ShowFiles()
        {
            var filesToShow = allFiles
                .Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .Select(f => new
                {
                    Name = f.Name,
                    Size = FormatFileSize(f.Length),
                    Created = f.CreationTime.ToString("dd.MM.yyyy HH:mm")
                });
            FilesListView.ItemsSource = filesToShow;
            UpdateStatus();
        }

        private string FormatFileSize(long bytes) {
            string[] sizes = { "B", "KB", "MB", "GB" };
            int order = 0;
            double len = bytes;
            while (len >= 1024 && order<sizes.Length - 1)
            {
                order++;
                len /= 1024;
            }
            return $"{len:0.##} {sizes[order]}";
        }

        private void UpdateStatus()
        {
            int totalPages = (int)Math.Ceiling((double)allFiles.Length / PageSize);
            StatusTextBlock.Text = $"Страница {CurrentPage} из {totalPages}";
            ShowMoreButton.IsEnabled = CurrentPage < totalPages;
        }

        private void ShowMoreButton_Click(object sender, RoutedEventArgs e)
        {
            CurrentPage++;
            ShowFiles();
        }
    }
}