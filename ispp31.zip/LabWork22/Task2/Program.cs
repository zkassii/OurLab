﻿class Program
{
    static async Task GetFileAsync(string fileName, int N)
    {
        Console.WriteLine($"Запись в файл {fileName} начата");
        using (StreamWriter writer = new(fileName, false))
        {
            Random random = new Random();
            for (int i = 1; i <= N; i++)
            {
                await writer.WriteLineAsync($"Число {i}: {random.Next()}");
            }
        }
        Console.WriteLine($"Запись в файл {fileName} закончена");
    }
    static async Task Main(string[] args)
    {
        await GetFileAsync("number.txt", 100000);
        Console.WriteLine("конец");
    }
}