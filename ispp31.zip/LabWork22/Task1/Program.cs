﻿class Program
{
    static async Task PowerAsync(double a, int x)
    {
        double result = Math.Pow(a, x);
        Console.WriteLine($"{a} ^ {x} = {result}");

    }

    private static async Task Main(string[] args)
    {
        Console.WriteLine("Последовательный вызов: ");
        await Task.Run(() => PowerAsync(2, 3));
        await Task.Run(() => PowerAsync(4, 4));
        await Task.Run(() => PowerAsync(5, 2));

        Console.WriteLine("Параллельный вызов: ");
        Task task1 = Task.Run(() => PowerAsync(2, 3));
        Task task2 = Task.Run(() => PowerAsync(4, 4));
        Task task3 = Task.Run(() => PowerAsync(5, 2));

        await Task.WhenAll(task1, task2, task3);
    }
}