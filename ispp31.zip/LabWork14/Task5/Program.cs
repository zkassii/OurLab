﻿using System.Text.RegularExpressions;

string datePattern = @"(?<day>(0?[1-9]|[12]\d|3[01]))[./](?<month>(0?[1-9]|1[0-2]))[./](?<year>\d{2,4})";
string replacementPattern = @"${year}-${month}-${day}";
string dates = "25.10.2024 и 02/08/52";

string formattedDates = Regex.Replace(dates, datePattern, replacementPattern);
Console.WriteLine($"Отформатированные даты: {formattedDates}");