﻿using System.Text.RegularExpressions;

string whitespacePattern = @"\s{2,}";
string textWithSpaces = "Лалалалл             лалал   лаллала";

string cleanedText = Regex.Replace(textWithSpaces, whitespacePattern, " ");
Console.WriteLine($"Текст с пробелами: {cleanedText}");