﻿public interface IPrinter
{
    void Print();
}