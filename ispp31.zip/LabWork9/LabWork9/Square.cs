﻿public class Square : IFigure, IPrinter
{
    public double Side { get; set; }
    public double GetArea() => Side * Side;
    public double GetPerimeter() => 4 * Side;

    public void PrintInfo()
         => Console.WriteLine($"Фигура {Name}, площадь {GetArea()}, периметр {GetPerimeter()}");

    public void Print()
        => PrintInfo();

    public string Name => "квадрат";
}