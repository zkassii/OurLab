﻿using System.ComponentModel;

User user = new User();
user.PropertyChanged += User_PropertyChanged;

user.Login = "Новый логин";
user.Password = "Новый пароль";
Console.ReadLine();

static void User_PropertyChanged(object sender, PropertyChangedEventArgs e)
    => Console.WriteLine($"Изменено свойство: {e.PropertyName}");