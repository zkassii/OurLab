﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

public class User : INotifyPropertyChanged
{
    private string _login;
    private string _password;

    public event PropertyChangedEventHandler PropertyChanged;
    public event EventHandler<InfoEventArgs> UserChanged;

    public string Login
    {
        get => _login;
        set
        {
            if (_login != value)
            {
                _login = value;
                OnPropertyChanged();
                OnUserChanged();
            }
        }
    }

    public string Password
    {
        get => _password;
        set
        {
            if (_password != value)
            {
                _password = value;
                OnPropertyChanged();
                OnUserChanged();
            }
        }
    }
    public void OnUserChanged(string propertyName = "") 
        => UserChanged?.Invoke(this, new EventArgs.Empty());

    public void OnPropertyChanged([CallerMemberName] string propertyName = "")
       => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}