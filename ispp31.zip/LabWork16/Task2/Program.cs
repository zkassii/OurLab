﻿using System.ComponentModel;

User user = new User();
user.PropertyChanged += User_PropertyChanged;

user.Login = "Новый логин";
user.Password = "Новый пароль";
Console.ReadLine();

static void User_PropertyChanged(object sender, EventArgs e)
{ 
    var user = sender as User;
    Console.WriteLine($"Изменены данные пользователя со следующим логином: {user?.Login}");
}