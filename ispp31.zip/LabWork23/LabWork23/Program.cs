﻿using LabWorkLibrary;

Console.WriteLine($"Константа: {Maths.BinaryFactor}");
Console.WriteLine($"5 + 5 = {Maths.GetSum(5, 5)}");
Console.WriteLine($"5 - 5 = {Maths.GetDifference(5, 5)}");
Console.WriteLine($"5 * 5 = {Maths.GetProduct(5, 5)}");
Console.WriteLine($"5 / 5 = {Maths.GetQuotient(5, 5)}");
Console.WriteLine($"Площадь прямоугольника со сторонами 5 и 5 = {Maths.GetRectangleArea(5, 5)}");