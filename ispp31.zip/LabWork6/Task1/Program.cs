﻿using LabWork6;

class Program
{
    public static double Perimeter(double side)
    {
        return 4 * side;
    }

    public static double Perimeter(double length, double width)
    {
        return 2 * (length + width);
    }

    public static int Power(int x, int n)
    {

        if (n < 0)
            return -1;
        
        int result = 1;
        for (int i = 0; i < n; i++)
            result *= x;
        return result;

    }

    public static int Power(int x)
    {
        return x * x;
    }

    static void Main(string[] args)
    {
        Customer defaultCustomer = new();
        Console.WriteLine("Тестирование конструктора по умолчанию:");
        defaultCustomer.DisplayValues();

        Customer NamedCustomer = new("Пушкина Анастасия Андреевна", "Архангельск, ул. Урицкого, д. 11", 6362.1);
        Console.WriteLine("Тестирование конструктора с параметрами:");
        NamedCustomer.DisplayValues();

        Console.WriteLine();
        Console.WriteLine("Тестирование индексаторов:");
        Console.WriteLine($"Имя: {NamedCustomer["name"]}");
        Console.WriteLine($"Адрес: {NamedCustomer["address"]}");
        Console.WriteLine($"Потраченная сумма: {NamedCustomer["spentAmount"]}");

        Console.WriteLine($"Символ имени по индексу 1: {NamedCustomer[2]}");
        Console.WriteLine($"Символ имени по некорректному индексу: {NamedCustomer[46]}");

        Console.WriteLine();
        Console.WriteLine($"Периметр квадрата со стороной 5: {Perimeter(5)}");
        Console.WriteLine($"Периметр прямоугольника с длиной 4 и шириной 5: {Perimeter(4, 5)}");

        Console.WriteLine();
        Console.WriteLine($"2 в 3 степени: {Power(2, 3)}");
        Console.WriteLine($"2 в степени -2: {Power(2, -2)}");
        Console.WriteLine($"х во 2 степени: {Power(2)}");
    }
}