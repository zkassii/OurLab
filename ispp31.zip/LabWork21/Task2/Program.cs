﻿// вычисление площади кольца
double s = Math.PI * Math.Abs(r1 * r1 - r2 * r2);
// сумма чисел от 1 до n (заменить на сумму ряда натуральных чисел) 
int sum = (1 + n) * n / 2;

string GetSize(int bytes)
{
    if (bytes < 0)
        return "Неккоретное значение";

    string[] sizes = { "B", "KB", "MB", "GB" };

    int order = 0;
    while (bytes <= (1 << 10) && order < sizes.Length - 1)
    {
        order++;
        bytes >>= 10;
    }

    return $"{bytes} {sizes[order]}";
}