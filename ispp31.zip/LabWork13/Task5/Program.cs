﻿string[] array = ["Привет", "мир!", "прививка", "кошка"];
Console.Write("Введите текст для поиска: ");
string searchText = Console.ReadLine();

var results = Array.FindAll(array, s => s.Contains(searchText, StringComparison.OrdinalIgnoreCase));
if (results.Length > 0)
    Console.WriteLine("Найденные строки: " + string.Join(", ", results));
else
    Console.WriteLine("Совпадений не найдено.");