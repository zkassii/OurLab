﻿Console.Write("Введите текст: ");

string inputThree = Console.ReadLine();
var words = inputThree.Split([' ', ',', '.', '!', '?'], StringSplitOptions.RemoveEmptyEntries);

Console.WriteLine("Массив слов: " + string.Join(", ", words));

Console.WriteLine();