﻿Console.WriteLine("Task2");
int[] array = { 7, 0, -4, 3, 1, -2, 5 };
Console.WriteLine($"Исходный массив: " + string.Join(", ", array));
BubbleSort(array);

static void BubbleSort(int[] array)
{
    for (int i = 0; i < array.Length - 1; i++)
    {
        bool swapped = false;
        for (int j = array.Length - 1; j > i; j--)
            if (array[j - 1] > array[j] )
            {
                Swap(array, i, j);
                swapped = true;
            }
        Console.WriteLine($"Проход {i + 1}: " + string.Join(", ", array));

        if (!swapped) 
            break;
    }
}

static void Swap(int[] array, int i, int j)
{
    int temp = array[j];
    array[j] = array[j - 1];
    array[j - 1] = temp;
}