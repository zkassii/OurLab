﻿// 1 
List<string> vegetables = ["Картофель", "Морковь", "Помидор"];
Console.Write("Введите количество овощей для добавления: ");
int count = int.Parse(Console.ReadLine());

for (int i = 0; i < count; i++)
{
    Console.Write("Введите название овоща: ");
    string vegetable = Console.ReadLine();
    vegetables.Add(vegetable);
}

Console.WriteLine("Элементы списка:");
for (int i = 0; i < vegetables.Count; i++)
    Console.WriteLine($"{i + 1} - {vegetables[i]}");

Console.WriteLine($"Количество элементов списка: {vegetables.Count}");
Console.WriteLine();

// 2 

Dictionary<string, string> firmDictionary = new()
{
    { "КФХ Диана", "Беларусь" },
    { "WOHUA", "Китай" },
    { "Шаньдун Ляньчэн Лтд", "Китай" }
};

Console.Write("Введите количество пар ключ-значение для добавления: ");
int firmsCount = int.Parse(Console.ReadLine());

for (int i = 0; i < firmsCount; i++)
{
    Console.Write("Введите название фирмы (ключ): ");
    string key = Console.ReadLine();
    Console.Write("Введите страну (значение): ");
    string value = Console.ReadLine();
    firmDictionary[key] = value;
}

Console.WriteLine("Содержимое словаря:");

foreach (var item in firmDictionary)
    Console.WriteLine($"{item.Key} - {item.Value}");

Console.WriteLine($"Количество элементов словаря: {firmDictionary.Count}");
Console.WriteLine();

// 3

Console.Write("Введите ключ для поиска: ");
string searchKey = Console.ReadLine();

if (firmDictionary.TryGetValue(searchKey, out string country))
    Console.WriteLine($"Ключ '{searchKey}' найден, значение: {country}");
else
    Console.WriteLine($"Ключ '{searchKey}' отсутствует в словаре.");

Console.Write("Введите значение для подсчета совпадений: ");
string searchValue = Console.ReadLine();
count = 0;

foreach (var item in firmDictionary.Values)
    if (item.Equals(searchValue))
        count++;

Console.WriteLine($"Количество совпадений: {count}");

Console.Write("Введите ключ для удаления: ");
string deleteKey = Console.ReadLine();

if (firmDictionary.Remove(deleteKey))
    Console.WriteLine($"Элемент с ключом '{deleteKey}' удален.");
else
    Console.WriteLine($"Ключ '{deleteKey}' не найден.");

Console.WriteLine("Содержимое словаря после удаления:");
foreach (var item in firmDictionary)
    Console.WriteLine($"{item.Key} - {item.Value}");

Console.WriteLine();

//4

vegetables.Sort((x, y) => y.CompareTo(x));
Console.Write("Введите количество элементов для вывода: ");
int outputCount = int.Parse(Console.ReadLine());

Console.WriteLine("Отсортированные элементы списка:");
for (int i = 0; i < Math.Min(outputCount, vegetables.Count); i++)
    Console.WriteLine(vegetables[i]);