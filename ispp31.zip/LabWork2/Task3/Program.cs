﻿int[] array = { 1, 3, 5, 7, 9 };
int value = 29;

int result = JumpSearch(array, value);
Console.WriteLine($"Элемент {value}, позиция {result}");

static int JumpSearch(int[] array, int value)
{
    int n = array.Length;
    int step = (int)Math.Sqrt(n);
    int jump = step;
    int previous = 0;

    while (array[Math.Min(jump, n) - 1] < value)
    {
        previous = jump;
        jump += step;

        if (previous >= n)
            return -1;
    }

    while (array[previous] < value)
    {
        previous++;

        if (previous == Math.Min(jump, n))
            return -1;
    }
    return array[previous] == value ? previous : -1;
}

