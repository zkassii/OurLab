﻿int[] array = { 1, 2, 3, 4, 5, 6, 7 };
int value = 5;

int result = BinarySearch(array, value);
Console.WriteLine($"Элемент {value}, позиция {result}");

static int BinarySearch(int[] array, int value)
{
    int left = 0, right = array.Length - 1;

    while (left <= right)
    {
        int middle = left + (right - left) / 2;
        if (array[middle] == value)
            return middle;

        if (array[middle] < value)
            left = middle + 1;
        else
            right = middle - 1;
    }
    return -1;
}