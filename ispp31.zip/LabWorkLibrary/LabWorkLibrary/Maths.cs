﻿namespace LabWorkLibrary
{
    public static class Maths
    {
        /// <summary>
        /// 2^10 
        /// </summary>
        public const int BinaryFactor = 1024;

        /// <summary>
        /// Вычисление суммы двух чисел
        /// </summary>
        /// <param name="a">первое слагаемое</param>
        /// <param name="b">второе слагаемое</param>
        /// <returns>Сумма двух чисел</returns>
        public static double GetSum(double a, double b)
            => a + b;

        /// <summary>
        /// Вычисление разности двух чисел
        /// </summary>
        /// <param name="a">уменьшаемое</param>
        /// <param name="b">вычитаемое</param>
        /// <returns>Разность двух чисел</returns>
        public static double GetDifference(double a, double b)
            => a - b;

        /// <summary>
        /// Вычисление произведения двух чисел
        /// </summary>
        /// <param name="a">первый множитель</param>
        /// <param name="b">второй множитель</param>
        /// <returns>Произведение двух чисел</returns>
        public static double GetProduct(double a, double b)
            => a * b;

        /// <summary>
        /// Вычисление частного двух чисел
        /// </summary>
        /// <param name="a">делимое</param>
        /// <param name="b">делитель</param>
        /// <returns>Частное двух чисел</returns>
        public static double GetQuotient(double a, double b)
            => a / b;

        /// <summary>
        /// Вычисление площади прямоугольника
        /// </summary>
        /// <param name="weight">ширина</param>
        /// <param name="height">высота</param>
        /// <returns>Площадь прямоугольника</returns>
        public static double GetRectangleArea(double weight, double height)
            => weight * height;
    }
}