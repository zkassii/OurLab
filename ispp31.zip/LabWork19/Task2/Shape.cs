﻿interface IShape
{
    void Draw();
}