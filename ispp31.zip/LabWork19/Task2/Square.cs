﻿public class Square : IShape
{
    public void Draw()
    {
        Console.WriteLine("квадрат");
    }
}