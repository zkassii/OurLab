﻿public class Program
{

    public static void main(String[] args)
    {
        ShapeFactory shapeFactory = new();

        //get an object of Circle and call its draw method.
        IShape shape1 = shapeFactory.GetShape("круг");

        //call draw method of Circle
        shape1.Draw();

        //get an object of Rectangle and call its draw method.
        IShape shape2 = shapeFactory.GetShape("прямоугольник");

        //call draw method of Rectangle
        shape2.Draw();

        //get an object of Square and call its draw method.
        IShape shape3 = shapeFactory.GetShape("квадрат");

        //call draw method of square
        shape3.Draw();
    }
}