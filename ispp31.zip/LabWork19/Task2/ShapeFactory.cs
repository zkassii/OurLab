﻿public class ShapeFactory
{
    public IShape GetShape(string shapeType) 
    { 
        if (shapeType == null)
        {
            return null;
        }

        if (shapeType.Equals("круг"))
            return new Circle();

        else if (shapeType.Equals("квадрат"))
            return new Square();

        else if (shapeType.Equals("прямоугольник"))
            return new Rectangle();

        return null;
    }
}