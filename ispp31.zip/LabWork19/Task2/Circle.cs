﻿public class Circle : IShape
{
    public void Draw() 
    {
        Console.WriteLine("круг");    
    }
}