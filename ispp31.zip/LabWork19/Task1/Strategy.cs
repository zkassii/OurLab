﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{

    interface IStrategy
    {
         public int DoOperation(int number1, int number2);
    }
}