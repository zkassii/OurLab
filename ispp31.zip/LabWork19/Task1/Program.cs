﻿using Task1;

public class Program
{
    public static void main(String[] args)
    {
        Context context = new(new OperationAdd());
        Console.WriteLine($"10 + 5 = {context.ExecuteStrategy(10, 5)}");

        context = new Context(new OperationSubstract());
        Console.WriteLine($"10 - 5 = {context.ExecuteStrategy(10, 5)}");

        context = new Context(new OperationMultiply());
        Console.WriteLine($"10 * 5 = {context.ExecuteStrategy(10, 5)}");

        context = new Context(new OperationDivide());
        Console.WriteLine($"10 / 5 = {context.ExecuteStrategy(10, 5)}");
    }
}