﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Task1
{
    public class OperationMultiply : IStrategy
    {
        public int DoOperation(int number1, int number2)
        {
            return number1 * number2;
        }
    }
}