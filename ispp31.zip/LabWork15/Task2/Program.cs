﻿MyVoidDelegate myVoidDelegate = Sum;
myVoidDelegate += Subtract;
myVoidDelegate += Multiplication;
myVoidDelegate += Division;

myVoidDelegate(15, 5); 

static void Sum(int a, int b) 
    => Console.WriteLine($"Сумма: {a + b}");
static void Subtract(int a, int b) 
    => Console.WriteLine($"Разность: {a - b}");
static void Multiplication(int a, int b) 
    => Console.WriteLine($"Произведение: {a * b}");
static void Division(int a, int b) 
    => Console.WriteLine($"Частное: {a / b}");
