﻿MyDelegate myDelegate = Square;
Console.WriteLine($"Квадрат: {myDelegate(5)}");

myDelegate = Factorial;
Console.WriteLine($"Факториал: {myDelegate(5)}");

myDelegate = Absolute;
Console.WriteLine($"Модуль: {myDelegate(-5)}");

static int Square(int x) => x * x;
static int Factorial(int x)
{
    if (x < 0)
        return 0;
    int result = 1;
    for (int i = 1; i <= x; i++)
        result *= i;
    return result;
}
static int Absolute(int x)
    => x < 0 ? -x : x;


MyDelegate[] delegates = [Square, Factorial, Absolute];

foreach (var myDel in delegates)
{
    Console.WriteLine(myDel(5));
}