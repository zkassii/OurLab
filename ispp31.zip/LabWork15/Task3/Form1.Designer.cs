﻿namespace Task3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBoxReplaceText = new TextBox();
            buttonReplacement = new Button();
            SuspendLayout();
            // 
            // textBoxReplaceText
            // 
            textBoxReplaceText.Location = new Point(257, 159);
            textBoxReplaceText.Multiline = true;
            textBoxReplaceText.Name = "textBoxReplaceText";
            textBoxReplaceText.Size = new Size(136, 73);
            textBoxReplaceText.TabIndex = 0;
            // 
            // buttonReplacement
            // 
            buttonReplacement.Location = new Point(84, 159);
            buttonReplacement.Name = "buttonReplacement";
            buttonReplacement.Size = new Size(121, 73);
            buttonReplacement.TabIndex = 1;
            buttonReplacement.Text = "Замена";
            buttonReplacement.UseVisualStyleBackColor = true;
            buttonReplacement.Click += buttonReplacement_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonReplacement);
            Controls.Add(textBoxReplaceText);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxReplaceText;
        private Button buttonReplacement;
    }
}
