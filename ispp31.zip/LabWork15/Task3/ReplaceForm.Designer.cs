﻿namespace Task3
{
    partial class ReplaceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonReplace = new Button();
            SuspendLayout();
            // 
            // buttonReplace
            // 
            buttonReplace.Location = new Point(114, 120);
            buttonReplace.Name = "buttonReplace";
            buttonReplace.Size = new Size(111, 54);
            buttonReplace.TabIndex = 0;
            buttonReplace.Text = "Замена";
            buttonReplace.UseVisualStyleBackColor = true;
            // 
            // ReplaceForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonReplace);
            Name = "ReplaceForm";
            Text = "ReplaceForm";
            ResumeLayout(false);
        }

        #endregion

        private Button buttonReplace;
    }
}