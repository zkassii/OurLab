namespace Task3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonReplacement_Click(object sender, EventArgs e)
        {
            ReplaceForm replaceForm = new ReplaceForm(textBoxReplaceText);

            replaceForm.ShowDialog();
        }
    }
}
